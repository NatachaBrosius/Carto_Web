TP1 Cartographie Web

Mon projet est la réalisation d’un site Web sur les écoles de la commission scolaire de La Capitale qui serait un bon départ pour mon projet d’ASP. Il se constitue de 3 pages html :
1.	Carte : qui porte la carte web avec l’affichage des écoles
2.	A propos : qui détail le but du projet final
3.	Contact : un formulaire de contact
Les trois pages sont appelables depuis les unes ou les autres, néanmoins commencer par ouvrir dans le live server Carte car ce serait ma page d’accueil.
